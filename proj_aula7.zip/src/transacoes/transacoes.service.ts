import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Transacao } from './schemas/transacao.schema.js';
import type { TransacaoDocument } from './schemas/transacao.schema.js';
import { CreateTransacaoDto } from './dto/create-transacao.dto.js';

@Injectable()
export class TransacoesService {
  constructor(
    @InjectModel(Transacao.name)
    private readonly transacaoModel: Model<TransacaoDocument>,
  ) {}

  async create(dto: CreateTransacaoDto) {
    const transacao = new this.transacaoModel(dto);
    return transacao.save();
  }

  async findAll() {
    const historico = await this.transacaoModel
      .find()
      .sort({ createdAt: -1 })
      .exec();

    let totalReceitas = 0;
    let totalDespesas = 0;
    let totalGastoImpulso = 0;

    for (const t of historico) {
      if (t.tipo === 'receita') {
        totalReceitas += t.valor;
      } else if (t.tipo === 'despesa') {
        totalDespesas += t.valor;
        if (t.consumoConsciente === false) {
          totalGastoImpulso += t.valor;
        }
      }
    }

    return {
      historico,
      metricas: {
        saldoTotal: totalReceitas - totalDespesas,
        totalDespesas,
        totalGastoImpulso,
      },
    };
  }
}
