import { Test } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { TransacoesService } from './transacoes.service.js';
import { Transacao } from './schemas/transacao.schema.js';

const historicoMock = [
  { descricao: 'Salário', valor: 3000, tipo: 'receita', categoria: 'Trabalho', consumoConsciente: true },
  { descricao: 'Conta de Luz', valor: 180, tipo: 'despesa', categoria: 'Moradia', consumoConsciente: true },
  { descricao: 'Compra de Roupas', valor: 250, tipo: 'despesa', categoria: 'Lazer', consumoConsciente: false },
];

describe('TransacoesService', () => {
  let service: TransacoesService;

  beforeEach(async () => {
    const modelMock = {
      find: () => ({ sort: () => ({ exec: async () => historicoMock }) }),
    };
    const moduleRef = await Test.createTestingModule({
      providers: [
        TransacoesService,
        { provide: getModelToken(Transacao.name), useValue: modelMock },
      ],
    }).compile();
    service = moduleRef.get(TransacoesService);
  });

  it('calcula as métricas corretamente', async () => {
    const res = await service.findAll();
    expect(res.historico).toHaveLength(3);
    expect(res.metricas).toEqual({
      saldoTotal: 2570,
      totalDespesas: 430,
      totalGastoImpulso: 250,
    });
  });
});
