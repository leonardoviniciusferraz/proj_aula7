import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import type { HydratedDocument } from 'mongoose';

export type TransacaoDocument = HydratedDocument<Transacao>;

@Schema({ timestamps: true })
export class Transacao {
  @Prop({ type: String, required: true })
  descricao: string;

  @Prop({ type: Number, required: true })
  valor: number;

  @Prop({ type: String, required: true, enum: ['receita', 'despesa'] })
  tipo: string;

  @Prop({ type: String, required: true })
  categoria: string;

  @Prop({ type: Boolean, default: true })
  consumoConsciente: boolean;
}

export const TransacaoSchema = SchemaFactory.createForClass(Transacao);
