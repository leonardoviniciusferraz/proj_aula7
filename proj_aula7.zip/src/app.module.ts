import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';
import { TransacoesModule } from './transacoes/transacoes.module.js';

@Module({
  imports: [
    // A string de conexão do MongoDB Atlas vem da variável de ambiente MONGODB_URI
    // (assim a senha não fica publicada no GitHub).
    MongooseModule.forRoot(
      process.env.MONGODB_URI ??
        'mongodb+srv://<usuario>:<senha>@<cluster>.mongodb.net/financas?retryWrites=true&w=majority',
    ),
    TransacoesModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
