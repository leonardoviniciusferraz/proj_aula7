import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { TransacoesController } from './../src/transacoes/transacoes.controller.js';
import { TransacoesService } from './../src/transacoes/transacoes.service.js';

describe('Transacoes (e2e)', () => {
  let app: INestApplication;
  const serviceMock = {
    create: async (dto: unknown) => ({ _id: '1', ...(dto as object) }),
    findAll: async () => ({
      historico: [],
      metricas: { saldoTotal: 0, totalDespesas: 0, totalGastoImpulso: 0 },
    }),
  };

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [TransacoesController],
      providers: [{ provide: TransacoesService, useValue: serviceMock }],
    }).compile();
    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterEach(async () => {
    await app.close();
  });

  it('POST /transacoes cria uma transação válida', () =>
    request(app.getHttpServer())
      .post('/transacoes')
      .send({ descricao: 'Salário', valor: 3000, tipo: 'receita', categoria: 'Trabalho' })
      .expect(201));

  it('POST /transacoes rejeita tipo inválido', () =>
    request(app.getHttpServer())
      .post('/transacoes')
      .send({ descricao: 'X', valor: 10, tipo: 'teste', categoria: 'Lazer' })
      .expect(400));

  it('GET /transacoes devolve historico e metricas', async () => {
    const res = await request(app.getHttpServer()).get('/transacoes').expect(200);
    expect(res.body).toHaveProperty('historico');
    expect(res.body.metricas).toHaveProperty('saldoTotal');
  });
});
